# Temperature Converter Website - Oasis Infobyte Internship

**Name:** Barthala BalaHariHaran  
**Internship:** Oasis Infobyte - Web Development  
**Task:** Level 1 - Task 3  
**Description:**  
A responsive temperature converter website where users can input a temperature in Celsius, Fahrenheit, or Kelvin and get the converted value in the other two units.

## Features
- Input temperature
- Select unit (°C, °F, K)
- Instant conversion on button click
- Styled UI with CSS

## Technologies Used
- HTML
- CSS
- JavaScript
