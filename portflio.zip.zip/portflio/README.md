# Portfolio Website

This is Level 1 - Task 2 for the Oasis Infobyte Internship.

## 🔧 Technologies Used:
- HTML
- CSS

## 📁 Files:
- index.html
- style.css
- README.md
