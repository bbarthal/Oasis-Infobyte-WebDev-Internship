# Landing Page - Oasis Infobyte Internship

## Task
This is Level 1 - Task 1 of the Oasis Infobyte Web Development Internship.  
The goal is to build a landing page using HTML and CSS.

## What I Learned
- HTML structure
- CSS styling
- Layout using Flexbox
- Design alignment and color usage

## Files Included
- index.html
- style.css

## How to View
1. Open index.html in a browser using Live Server
2. You will see the landing page design

## Status
✅ Task Completed!
